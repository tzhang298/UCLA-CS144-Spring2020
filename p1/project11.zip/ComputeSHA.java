import java.io.*;
import java.security.*;
import java.util.Formatter;


public class ComputeSHA{
    public static void main(String args[]) throws IOException{


      try {
        FileInputStream fis = new FileInputStream(args[0]);
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] bytes = new byte[1024];
        int nread = 0;
        while ((nread = fis.read(bytes)) != -1) {
              md.update(bytes, 0, nread);
        }
        byte[] byteData = md.digest();

  		  StringBuffer hexString = new StringBuffer();
        for(int i = 0; i < byteData.length; i++){
    			String hex = Integer.toHexString(0xFF & byteData[i]);
    			if(hex.length() == 1)
    				hexString.append('0');
    			hexString.append(hex);
  		  }
        String result = hexString.toString();
        System.out.println(result);
  		} catch(Exception e) {
  			System.out.println("Exception: " + e);
  		}


    }
}
